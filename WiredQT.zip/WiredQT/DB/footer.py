	def Widget(self):
		return self
