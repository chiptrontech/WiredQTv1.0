cd /home/pi/Desktop/WiredQT.py
python3 WiredQT.py
